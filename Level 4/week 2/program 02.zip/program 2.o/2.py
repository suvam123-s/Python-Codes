# Function to convert Celsius to Fahrenheit
def celsius_to_fahrenheit(celsius):
    return (celsius * 9/5) + 32

# Prompt the user for temperature in Celsius
while True:
    try:
        celsius_input = float(input("Enter a temperature in Celsius: "))
        break
    except ValueError:
        print("Invalid input. Please enter a numeric value.")

# Calculate the corresponding temperature in Fahrenheit
fahrenheit_output = celsius_to_fahrenheit(celsius_input)

# Display the result
print(f"{celsius_input}C is equivalent to {fahrenheit_output}F.")
