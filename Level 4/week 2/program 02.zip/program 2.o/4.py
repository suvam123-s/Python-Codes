def distribute_sweets():
    # Input: number of sweets and number of pupils
    while True:
        try:
            total_sweets = int(input("Enter the total number of sweets: "))
            if total_sweets < 0:
                print("The total number of sweets cannot be negative. Please enter a non-negative number.")
                continue
            break
        except ValueError:
            print("Invalid input. Please enter a valid integer for the total number of sweets.")
    
    while True:
        try:
            number_of_pupils = int(input("Enter the number of pupils: "))
            if number_of_pupils <= 0:
                print("The number of pupils must be greater than zero.")
                continue
            break
        except ValueError:
            print("Invalid input. Please enter a valid integer for the number of pupils.")
        
        
        # Calculate sweets per pupil and sweets left over
        sweets_per_pupil = total_sweets // number_of_pupils
        sweets_left_over = total_sweets % number_of_pupils
        
        # Output the results
        print(f"Each pupil will receive: {sweets_per_pupil} sweets.")
        print(f"Sweets left over: {sweets_left_over} sweets.")
    
   