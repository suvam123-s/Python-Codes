# Program to greet the user

# Ask the user for their name
name = input("Hello, what is your name? ")

# Print a greeting message
print(f"Hello, {name}. Good to meet you!")