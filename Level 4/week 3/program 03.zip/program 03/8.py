# Function to print the times table
def print_times_table(number):
    # Check if the number is zero
    if number == 0:
        print("The times table for 0 will only produce 0s.")
        for i in range(13):
            print(f"{number} times {i} = 0")
    elif number < 0:
        # If the number is negative, print the table backwards
        abs_number = abs(number)
        print(f"\nTimes Table for -{abs_number} (in reverse)")
        print("-----------------------------------")
        for i in range(12, -1, -1):  # Loop from 12 down to 0
            print(f"{abs_number} times {i} = {abs_number * i}")
    else:
        # If the number is positive, print the table normally
        print(f"\nTimes Table for {number}")
        print("-------------------------")
        for i in range(13):  # Loop from 0 to 12
            print(f"{number} times {i} = {number * i}")

# Get user input with input validation
while True:
    try:
        user_input = int(input("Enter the number for the times table: "))
        break
    except ValueError:
        print("Invalid input. Please enter an integer.")

print_times_table(user_input)
