def is_valid_password(password):
    # Check if the password is alphanumeric and meets basic strength requirements
    if len(password) < 8:
        print("Error: Password must be at least 8 characters long.")
        return False
    if not any(char.isdigit() for char in password):
        print("Error: Password must contain at least one number.")
        return False
    if not any(char.isalpha() for char in password):
        print("Error: Password must contain at least one letter.")
        return False
    if not password.isalnum():
        print("Error: Password must be alphanumeric (letters and numbers only).")
        return False
    return True

# Initialize counters for bad and valid passwords
bad_password_count = 0
valid_password_count = 0

# Allow user to enter passwords
while True:
    password = input("Enter a password (or type 'exit' to quit): ")
    
    if password.lower() == 'exit':
        break  # Exit the loop if the user types 'exit'
    
    if not is_valid_password(password):
        print(f"'{password}' is a bad password.")
        bad_password_count += 1
    else:
        print(f"'{password}' is a valid password.")
        valid_password_count += 1

print(f"\nTotal bad passwords: {bad_password_count}")
print(f"Total valid passwords: {valid_password_count}")
