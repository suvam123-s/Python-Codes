def display_multiplication_table(multiplier=7, up_to=12):
    print(f"{multiplier} Times Table")
    print("------------------")
    print("Number\t| Result")
    print("------------------")

    for i in range(up_to + 1):  # Loop from 0 to 'up_to' inclusive
        result = multiplier * i
        print(f"{i}\tx {multiplier} = {result}")

# Display the Seven Times Table
display_multiplication_table()
